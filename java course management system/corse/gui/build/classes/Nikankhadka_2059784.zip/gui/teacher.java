
package gui;
import java.awt.Color;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import net.proteanit.sql.DbUtils;



public class teacher extends mysqlfunctions{
    JFrame trpage= new JFrame("Teacher Dashboard");
    ImageIcon trimage=new ImageIcon("C:\\Users\\nikhi\\Desktop\\corse\\adminicon.png");
    
    
    JPanel header=new JPanel();
  
    
    
    JPanel body=new JPanel();
    //options for admins 
    JButton courses=  new JButton(new ImageIcon("C:\\Users\\nikhi\\Desktop\\corse\\course.png"));
    JButton mycourse=new JButton(new ImageIcon("C:\\Users\\nikhi\\Desktop\\corse\\course.png"));
 


   
    //for courses info
      
     int cour=0;
     int ncour=0;
    JPanel coursedisplay=new JPanel();
    JPanel cdheaderpanel=new JPanel();
    JButton forward=new JButton();
    JButton backward=new JButton();
    
    //panel for teache and module info
    JPanel teacherp=new JPanel();
    JButton update=new JButton("update Marks:");
    JTable jt=new JTable();
    JScrollPane scrollpane = new JScrollPane(jt);
    
     String course="";
           int year=0;
    

String id="";
 public teacher(String id){
     this.id=id;
 }          
           
           
           
           
           
           
           
           
           
           
           
           
           
   void   adminframe(){
        this.trpage.setSize(620,700);
        this.trpage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //  this.adpage.getContentPane().setBackground(new Color(142, 249, 157));
         this.trpage.setResizable(false); 
        this.trpage.setIconImage(trimage.getImage());
        this.trpage.setVisible(true);
        this.trpage.setLayout(null);
        
        
        //headerpanel
        this.trpage.add(header);
        this.headerpanel();
        
        //body panel
        this.trpage.add(body);
        bodypanel();
        
        
    }
   
   
   void headerpanel(){
       this.header.setBounds(0,0,105,700);
       this.header.setBackground(new Color(108, 223, 158));
       this.header.setLayout(null);
       this.header.add(courses);
       bcourses();
     
       
        this.header.add(mycourse);
        mycourse();
     
       
   }
    
  void bodypanel(){
      this.body.setBounds(105,0,620,700);
      this.body.setBackground(new Color(75, 179, 137));
      this.body.setLayout(null);
      
      
       
       body.add(coursedisplay);
       displaypanel();
       
       
       body.add(teacherp);
       teacherpanel();
  }
    
     void displaypanel(){ //panel for module information
       coursedisplay.setBounds(10,55,485,600);
       coursedisplay.setBackground(new Color(75, 179, 137));
       
      coursedisplay.setLayout(new GridLayout(1,1));
      coursedisplay.setVisible(false);
      
      body.add(cdheaderpanel);  //addingg header panel here because both are connected 
      
       coursedata();
     
    }
     
  void coursedata() {
        
         
         super.courselist();
        
           //for header panel hai contIns course details
           cdheaderpanel.setBounds(10,3,480,45);
           cdheaderpanel.setBackground(new Color(75, 179, 137));
           cdheaderpanel.setLayout(null);
           cdheaderpanel.setVisible(false);
           
           //add buttons inside header panel 
           cdheaderpanel.add(forward);
           forward.setBounds(395,5,60,35);
           forward.setText(">>>");
           
           forward.setFocusable(false);
           cdheaderpanel.add(backward);
           backward.setBounds(10,5,60,35);
           backward.setText("<<<");
          backward.setFocusable(false);
        
           JLabel cname=new JLabel();
           cdheaderpanel.add(cname);
           
           cname.setBounds(170,0,200,45);
           cname.setText("<html>"+courselist.get(cour)+"<br>"+"course credit:"+coursecredit.get(cour)+"</html>");
           cname.setFont(new Font("calibri",Font.PLAIN,15));
          //module info
           coursemodules(courselist.get(cour));
           
           //when forward and backward button are pressed 
           forward.addActionListener(e->{
              if(cour>=super.courselist.size()&&ncour<super.courselist1.size()){
                  
                  cname.setText("<html>"+super.courselist1.get(ncour)+"(Not Available)"+"<br>"+"course credit:"+super.coursecredit1.get(ncour)+"</html>");
                    coursedisplay.removeAll(); //cleans module panel 
                   coursemodules(super.courselist1.get(ncour));
                  ncour=ncour+1;
                  
              }
              else if (cour<super.courselist.size()){
             
                cour=cour+1;
                if (cour<super.courselist.size()){
                        cname.setText("<html>"+super.courselist.get(cour)+"<br>"+"course credit:"+super.coursecredit.get(cour)+"</html>");
               coursedisplay.removeAll();
               coursemodules(super.courselist.get(cour));
                }
                else{
                   
                    System.out.println("out of index");
                }
           }
           });
           
            backward.addActionListener(e->{
            if(cour>=super.courselist.size() &&ncour>0){
                
                    ncour=ncour-1;
                     cname.setText("<html>"+super.courselist1.get(ncour)+"(Not Available)"+"<br>"+"course credit:"+super.coursecredit1.get(ncour)+"</html>");
                    coursedisplay.removeAll();
                   coursemodules(super.courselist1.get(ncour));
                    
                
            }
            else{
                
                if(cour>0){
                
                 cour=cour-1;
              
               cname.setText("<html>"+super.courselist.get(cour)+"<br>"+"course credit:"+super.coursecredit.get(cour)+"</html>");
               coursedisplay.removeAll();
               coursemodules(super.courselist.get(cour));
           }}
            });                    
        
      }
   
   
    void coursemodules(String coursename){
       JLabel modules=new JLabel();
       System.out.println("coursemodules functrion chai call bhayo hai");
           try{
            mysqlfunctions db=new mysqlfunctions();
        
       
     
        ResultSet rs=db.stmt.executeQuery("select * from "+coursename+"");  
        String module="";
        
        int year1=0;
        while(rs.next()){
            
            if(rs.getInt("year")==year1){
                 module+=rs.getString("module_code")+":  "+rs.getString("module_name")+"<br>";
            }
            else{
                String year="year:"+rs.getString("year");
                module+="<h2>"+year+"</h2>"+rs.getString("module_code")+":  "+rs.getString("module_name")+"<br>";
            }

            year1=rs.getInt("year");
        }
     
         modules.setText("<html>"+module+"</html>");
        modules.setFont(new Font("serif",Font.PLAIN,14));
       
         coursedisplay.add(modules);
        }
       catch(Exception e){
            System.out.print("erororo"+e);
           
        }
    }

     
     
     
     
     
  
     
    void bcourses(){
        this.courses.setBounds(0,30,105,65);
        this.courses.setFocusable(false); //removes annoying box around text
        this.courses.setText("courses..");
         this.courses.setFont(new Font("serif",Font.PLAIN,14));
        this.courses.setBackground(new Color(128, 243, 193));
        
        //text align of button
        this.courses.setHorizontalTextPosition(SwingConstants.CENTER);
        this.courses.setVerticalTextPosition(SwingConstants.BOTTOM);
      
         this.courses.addActionListener(e->{
               teacherp.setVisible(false);
             cdheaderpanel.setVisible(true);
           coursedisplay.setVisible(true);
         
           
        });
       
        
    }
    
    
    
    
    
    
    
 
  
    
    
    void mycourse(){
        this.mycourse.setBounds(0,100,105,65);
        this.mycourse.setFocusable(false); //removes annoying box around text
        this.mycourse.setText("Mymodule");
         this.mycourse.setFont(new Font("serif",Font.PLAIN,14));
        this.mycourse.setBackground(new Color(128, 243, 193));
       
        //text align of button
        this.mycourse.setHorizontalTextPosition(SwingConstants.CENTER);
        this.mycourse.setVerticalTextPosition(SwingConstants.BOTTOM);
       mycourse.addActionListener(e->{
           cdheaderpanel.setVisible(false);
           coursedisplay.setVisible(false);
           teacherp.setVisible(true);
       });
     
        
        
        
    }
    
    
    void teacherpanel(){
       teacherp.setBounds(20,40,460,580);
       teacherp.setBackground(new Color(75, 179, 137));
       
     teacherp.setLayout(null);
     teacherp.setVisible(false);
     
     
     
     JLabel top=new JLabel();
     teacherp.add(top);
     top.setBounds(40,5,350,50);
     
     top.setText("Welcome To Teacher Dashboard:"+id);
     top.setFont(new Font("serif",Font.BOLD,18));
     
     
     //for modules info
     JLabel mod=new JLabel("Alloted Modules:");
     teacherp.add(mod);
     mod.setBounds(60,60,350,50);
      mod.setFont(new Font("serif",Font.BOLD,17));
     
      //module box
      JComboBox modulbox=new JComboBox();
      teacherp.add(modulbox);
      modulbox.setBounds(195,68,170,35);
      super.getmodules("tmodules",id);
      for(String c:super.modulelist){
          modulbox.addItem(c);
      }
      
      
      
      
      JButton details=new JButton("Details");
      teacherp.add(details);
      details.setBounds(180,120,100,35);
      details.addActionListener(e->{
          String module=String.valueOf(modulbox.getSelectedItem());
          displaystunts(module);
      });
      
      
      //now create a table 
     teacherp.add(scrollpane);
     scrollpane.setBounds(10,180,440,300);
     
     
    updatemarksbtn();
   
    }
    
    
   
    
 
    
    
   void displaystunts(String module){
        try{
            mysqlfunctions db=new mysqlfunctions();
           super.courselist();
          
           for(String course1:super.courselist){
               System.out.println(course1);
               System.out.println(module);
               ResultSet rs=db.stmt.executeQuery("select * from "+course1+" where module_code = '" + module + "'");
               if(rs.next()){
                   year=rs.getInt("year");
                   course=course1;
                   int value=1;
                   ResultSet rs1=db.stmt.executeQuery("select Student_id,"+module+" from "+course+"_year"+year+" where "+module+" >= '" + value + "'");  
           
                   jt.setModel(DbUtils.resultSetToTableModel(rs1));
                   break;
               }
               else{
                   System.out.println("module no matched in anyofthe course");
               }
           }
             //since we know course and year of the specific module
             
           
           
            
        }catch(Exception e){
             //JOptionPane.showMessageDialog(null,"select valid course/year","no details to show",JOptionPane.ERROR_MESSAGE);
            System.out.println("eororo"+e);
          
        }
    }
    
    
    
    public void updatemarksbtn(){
         //upate marks button to update 
    
     teacherp.add(update);
     update.setBounds(170,500,130,35);
     update.addActionListener(e->{
         int row =jt.getSelectedRow();
         String module=jt.getColumnName(1);
         String id=(String)jt.getValueAt(row,0);
         String upmarks=String.valueOf(jt.getValueAt(row, 1));
        super.updatemarks(id,module,upmarks,course,year);
         
     });
       
    }
    
    
    
    
    
    


    
    
    public static void main (String []args){
        teacher ad=new teacher("nikan123");
        ad.adminframe();
        
        
    }
    
}
