
package gui;



public interface loginpage {
    
    
    public void loginframe();
        
    
}
